package com.example.aplicativotrabalhowaterremember;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Settings extends AppCompatActivity {

    private Button btnCalcule;

    private TextView txtResultado;

    private EditText edTxtPeso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        btnCalcule = findViewById(R.id.btnCalcule);
        txtResultado = findViewById(R.id.txtResultado);
        edTxtPeso = findViewById(R.id.edTxtPeso);

        btnCalcule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double peso = Double.parseDouble(edTxtPeso.getText().toString());
                 txtResultado.setText( "Você deve ingerir "+(Double.parseDouble(edTxtPeso.getText().toString())*35)+" ml de água ");
                 Dados dado = new Dados(0,peso);
            }
        });
        }
    }
