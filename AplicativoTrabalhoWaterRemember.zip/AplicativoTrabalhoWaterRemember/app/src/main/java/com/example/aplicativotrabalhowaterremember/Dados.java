package com.example.aplicativotrabalhowaterremember;


import java.text.SimpleDateFormat;
import java.util.Date;

public class Dados {
    private  String data;
    private int qntcopos;
    private Double peso;
    private BancoDados bd;
    public Dados( int qntcopos, Double peso) {

        Date dataHoraAtual = new Date();
        this.data = new SimpleDateFormat("yyyy/MM/dd").format(dataHoraAtual);
        this.qntcopos = qntcopos;
        this.peso = peso;
        bd.SalvaInfo(this);

    }

    public Dados(){}

    public String getData() {
        Dados dado = bd.PegaInfo(this);
        return dado.data;
    }

    public void setData(String data) {

        this.data = data;
    }

    public int getQntcopos() {
        Dados dado = bd.PegaInfo(this);
        return dado.qntcopos;
    }

    public void setQntcopos(int qntcopos) {

        this.qntcopos = qntcopos;
        bd.SalvaInfo(this);
    }

    public Double getPeso() {
        Dados dado = bd.PegaInfo(this);
        return dado.peso;

    }

    public void setPeso(Double peso) {
        this.peso = peso;
        bd.SalvaInfo(this);
    }

    public void salvar(){
        bd.SalvaInfo(this);
        bd.SalvaInfo(this);
    }
}
